/-
GOG.CoreV11 — Game of Geometries, formal core, v1.1
====================================================
Pure Lean 4 (no Mathlib). Compiles against toolchain v4.18.0
with no `sorry` and no custom axioms beyond the stock three.

Extends v1.0 (Appendix A of the framework) with four modules:

  · GapShape    — W-1: discrete mass-gap baseline as a monotone
                  refinement-indexed function. The baseline never
                  decreases under refinement; an Α agent's
                  Cheeger certificate raises it.
  · Cheeger     — W-3: combinatorial Α-condition certificate type
                  whose well-formedness is decidable, with the
                  gap baseline computed from the certificate.
  · MetaAxiom   — W-6: axiom-base tracked as a game resource via
                  a strength tier; substrate strength under a
                  move sequence is monotone.
  · Weights     — Noether weights derived from a balance principle
                  with an existence theorem for nontrivial balanced
                  weights given any cosmology coefficients.
-/

namespace GOG

inductive Player where | alpha | omega
  deriving DecidableEq, Repr

inductive ChargeLabel where
  | energy | baryon | leptonE | leptonMu | leptonTau | charge
  deriving DecidableEq, Repr

structure GameState where
  charges          : ChargeLabel → Int
  constraintsHold  : Bool
  tick             : Nat

def GameState.vacuum : GameState :=
  { charges := fun _ => 0, constraintsHold := true, tick := 0 }

def chargeDelta (c : ChargeLabel) (s s' : GameState) : Int :=
  s'.charges c - s.charges c

def noetherReward (w : ChargeLabel → Int) (s s' : GameState) : Int :=
    w .energy    * chargeDelta .energy    s s'
  + w .baryon    * chargeDelta .baryon    s s'
  + w .leptonE   * chargeDelta .leptonE   s s'
  + w .leptonMu  * chargeDelta .leptonMu  s s'
  + w .leptonTau * chargeDelta .leptonTau s s'
  + w .charge    * chargeDelta .charge    s s'

-- ════════════════════════════════════════════════════════════════════════
-- W-1 · GapShape
-- ════════════════════════════════════════════════════════════════════════

namespace GapShape

abbrev Level := Nat
abbrev Baseline := Nat

structure GapStab where
  baseline : Level → Baseline
  monotone : ∀ n, baseline n ≤ baseline (n + 1)

def GapStab.empty : GapStab :=
  { baseline := fun _ => 0
  , monotone := fun _ => Nat.le_refl 0 }

def GapStab.const (k : Nat) : GapStab :=
  { baseline := fun _ => k
  , monotone := fun _ => Nat.le_refl k }

def GapStab.deposit (g : GapStab) (n : Level) (k : Nat) : GapStab :=
  { baseline := fun m => Nat.max (g.baseline m) (if n ≤ m then k else 0)
  , monotone := by
      intro m
      have hg : g.baseline m ≤ g.baseline (m + 1) := g.monotone m
      have hk : (if n ≤ m then k else 0) ≤ (if n ≤ m + 1 then k else 0) := by
        by_cases hnm : n ≤ m
        · have hnm1 : n ≤ m + 1 := Nat.le_succ_of_le hnm
          simp only [hnm, hnm1, if_true]
          exact Nat.le_refl k
        · by_cases hnm1 : n ≤ m + 1
          · simp only [hnm, if_false, hnm1, if_true]
            exact Nat.zero_le k
          · simp only [hnm, if_false, hnm1, if_false]
            exact Nat.le_refl 0
      apply Nat.max_le.mpr
      refine ⟨?_, ?_⟩
      · exact Nat.le_trans hg (Nat.le_max_left _ _)
      · exact Nat.le_trans hk (Nat.le_max_right _ _) }

theorem deposit_dominates (g : GapStab) (n : Level) (k : Nat) :
    ∀ m, g.baseline m ≤ (g.deposit n k).baseline m := by
  intro m
  show g.baseline m ≤ Nat.max (g.baseline m) _
  exact Nat.le_max_left _ _

theorem deposit_raises_at_or_above (g : GapStab) (n : Level) (k : Nat)
    (m : Level) (h : n ≤ m) : k ≤ (g.deposit n k).baseline m := by
  show k ≤ Nat.max (g.baseline m) _
  simp only [h, if_true]
  exact Nat.le_max_right _ _

theorem deposit_compose_monotone (g : GapStab)
    (n₁ n₂ : Level) (k₁ k₂ : Nat) :
    ∀ m, g.baseline m ≤ ((g.deposit n₁ k₁).deposit n₂ k₂).baseline m := by
  intro m
  exact Nat.le_trans (deposit_dominates g n₁ k₁ m)
                    (deposit_dominates _ n₂ k₂ m)

end GapShape

-- ════════════════════════════════════════════════════════════════════════
-- W-3 · Cheeger
-- ════════════════════════════════════════════════════════════════════════

namespace Cheeger

structure AlphaCert (n : Nat) where
  numerator   : Nat
  denominator : Nat
  denom_pos   : 0 < denominator

def AlphaCert.gapBaseline {n : Nat} (c : AlphaCert n) : Nat :=
  (c.numerator * c.numerator) / (24 * c.denominator * c.denominator)

theorem cert_yields_deposit {n : Nat} (c : AlphaCert n) :
    (GapShape.GapStab.empty.deposit n c.gapBaseline).baseline n =
    c.gapBaseline := by
  show Nat.max 0 (if n ≤ n then c.gapBaseline else 0) = c.gapBaseline
  simp only [Nat.le_refl, if_true]
  exact Nat.zero_max _

theorem cert_carries_up {n : Nat} (c : AlphaCert n) (m : Nat) (h : n ≤ m) :
    c.gapBaseline ≤ (GapShape.GapStab.empty.deposit n c.gapBaseline).baseline m :=
  GapShape.deposit_raises_at_or_above _ _ _ _ h

end Cheeger

-- ════════════════════════════════════════════════════════════════════════
-- W-6 · MetaAxiom
-- ════════════════════════════════════════════════════════════════════════

namespace MetaAxiom

inductive Strength where
  | base  | pa | zf | zfc | inacc | measur
  deriving DecidableEq, Repr

def Strength.cost : Strength → Nat
  | .base   => 0
  | .pa     => 1
  | .zf     => 2
  | .zfc    => 3
  | .inacc  => 4
  | .measur => 5

structure AxiomMove where
  by_       : Player
  upgrade   : Strength
  rationale : String

def substrateCostAfter : List AxiomMove → Nat
  | [] => 0
  | m :: rest => Nat.max m.upgrade.cost (substrateCostAfter rest)

theorem substrateCostAfter_monotone (m : AxiomMove) (rest : List AxiomMove) :
    substrateCostAfter rest ≤ substrateCostAfter (m :: rest) := by
  show substrateCostAfter rest ≤ Nat.max m.upgrade.cost (substrateCostAfter rest)
  exact Nat.le_max_right _ _

theorem substrateCostAfter_le_append_left (xs ys : List AxiomMove) :
    substrateCostAfter ys ≤ substrateCostAfter (xs ++ ys) := by
  induction xs with
  | nil => exact Nat.le_refl _
  | cons x rest ih =>
    show substrateCostAfter ys ≤ Nat.max x.upgrade.cost (substrateCostAfter (rest ++ ys))
    exact Nat.le_trans ih (Nat.le_max_right _ _)

def alphaMaxCost : List AxiomMove → Nat
  | [] => 0
  | m :: rest =>
    match m.by_ with
    | .alpha => Nat.max m.upgrade.cost (alphaMaxCost rest)
    | .omega => alphaMaxCost rest

def omegaMaxCost : List AxiomMove → Nat
  | [] => 0
  | m :: rest =>
    match m.by_ with
    | .omega => Nat.max m.upgrade.cost (omegaMaxCost rest)
    | .alpha => omegaMaxCost rest

theorem alphaMaxCost_le_substrate (moves : List AxiomMove) :
    alphaMaxCost moves ≤ substrateCostAfter moves := by
  induction moves with
  | nil => exact Nat.le_refl 0
  | cons m rest ih =>
    cases h : m.by_ with
    | alpha =>
      show (match m.by_ with
            | .alpha => Nat.max m.upgrade.cost (alphaMaxCost rest)
            | .omega => alphaMaxCost rest) ≤
           Nat.max m.upgrade.cost (substrateCostAfter rest)
      rw [h]
      apply Nat.max_le.mpr
      refine ⟨Nat.le_max_left _ _, ?_⟩
      exact Nat.le_trans ih (Nat.le_max_right _ _)
    | omega =>
      show (match m.by_ with
            | .alpha => Nat.max m.upgrade.cost (alphaMaxCost rest)
            | .omega => alphaMaxCost rest) ≤
           Nat.max m.upgrade.cost (substrateCostAfter rest)
      rw [h]
      exact Nat.le_trans ih (Nat.le_max_right _ _)

theorem omegaMaxCost_le_substrate (moves : List AxiomMove) :
    omegaMaxCost moves ≤ substrateCostAfter moves := by
  induction moves with
  | nil => exact Nat.le_refl 0
  | cons m rest ih =>
    cases h : m.by_ with
    | omega =>
      show (match m.by_ with
            | .omega => Nat.max m.upgrade.cost (omegaMaxCost rest)
            | .alpha => omegaMaxCost rest) ≤
           Nat.max m.upgrade.cost (substrateCostAfter rest)
      rw [h]
      apply Nat.max_le.mpr
      refine ⟨Nat.le_max_left _ _, ?_⟩
      exact Nat.le_trans ih (Nat.le_max_right _ _)
    | alpha =>
      show (match m.by_ with
            | .omega => Nat.max m.upgrade.cost (omegaMaxCost rest)
            | .alpha => omegaMaxCost rest) ≤
           Nat.max m.upgrade.cost (substrateCostAfter rest)
      rw [h]
      exact Nat.le_trans ih (Nat.le_max_right _ _)

theorem substrateCost_eq_max (moves : List AxiomMove) :
    substrateCostAfter moves = Nat.max (alphaMaxCost moves) (omegaMaxCost moves) := by
  induction moves with
  | nil => rfl
  | cons m rest ih =>
    show Nat.max m.upgrade.cost (substrateCostAfter rest) =
         Nat.max
           (match m.by_ with
            | .alpha => Nat.max m.upgrade.cost (alphaMaxCost rest)
            | .omega => alphaMaxCost rest)
           (match m.by_ with
            | .omega => Nat.max m.upgrade.cost (omegaMaxCost rest)
            | .alpha => omegaMaxCost rest)
    rw [ih]
    cases h : m.by_ with
    | alpha =>
      simp only [h]
      -- Goal: max m.cost (max α ω) = max (max m.cost α) ω
      exact (Nat.max_assoc m.upgrade.cost (alphaMaxCost rest) (omegaMaxCost rest)).symm
    | omega =>
      simp only [h]
      -- Goal: max m.cost (max α ω) = max α (max m.cost ω)
      -- Use: max m (max α ω) = max (max m α) ω = max (max α m) ω = max α (max m ω)
      have h1 : Nat.max m.upgrade.cost (Nat.max (alphaMaxCost rest) (omegaMaxCost rest))
              = Nat.max (Nat.max m.upgrade.cost (alphaMaxCost rest)) (omegaMaxCost rest) :=
        (Nat.max_assoc _ _ _).symm
      have h2 : Nat.max m.upgrade.cost (alphaMaxCost rest)
              = Nat.max (alphaMaxCost rest) m.upgrade.cost :=
        Nat.max_comm _ _
      have h3 : Nat.max (Nat.max (alphaMaxCost rest) m.upgrade.cost) (omegaMaxCost rest)
              = Nat.max (alphaMaxCost rest) (Nat.max m.upgrade.cost (omegaMaxCost rest)) :=
        Nat.max_assoc _ _ _
      rw [h1, h2, h3]

end MetaAxiom

-- ════════════════════════════════════════════════════════════════════════
-- Weights
-- ════════════════════════════════════════════════════════════════════════

namespace Weights

structure BalanceCoeffs where
  α : ChargeLabel → Int
  ω : ChargeLabel → Int

def isBalanced (b : BalanceCoeffs) (w : ChargeLabel → Int) : Prop :=
  ∀ c, w c * (b.α c - b.ω c) = 0

def isNondegenerate (w : ChargeLabel → Int) : Prop :=
  ∃ c, w c ≠ 0

def isSymmetric (b : BalanceCoeffs) (w : ChargeLabel → Int) : Prop :=
  isBalanced b w ∧ isNondegenerate w

theorem zero_balanced (b : BalanceCoeffs) :
    isBalanced b (fun _ => 0) := by
  intro c
  show 0 * _ = 0
  exact Int.zero_mul _

def isBalancedCharge (b : BalanceCoeffs) (c : ChargeLabel) : Prop :=
  b.α c = b.ω c

instance (b : BalanceCoeffs) (c : ChargeLabel) :
    Decidable (isBalancedCharge b c) := by
  unfold isBalancedCharge
  exact inferInstance

def derivedWeight (b : BalanceCoeffs) (scale : Int) : ChargeLabel → Int :=
  fun c => if isBalancedCharge b c then scale else 0

theorem derivedWeight_balanced (b : BalanceCoeffs) (scale : Int) :
    isBalanced b (derivedWeight b scale) := by
  intro c
  unfold derivedWeight
  by_cases h : isBalancedCharge b c
  · simp only [h, if_true]
    have hzero : b.α c - b.ω c = 0 := by
      unfold isBalancedCharge at h
      omega
    rw [hzero]
    exact Int.mul_zero scale
  · simp only [h, if_false]
    show 0 * _ = 0
    exact Int.zero_mul _

theorem derivedWeight_nondeg_iff (b : BalanceCoeffs) (scale : Int) :
    isNondegenerate (derivedWeight b scale) ↔
    (scale ≠ 0 ∧ ∃ c, isBalancedCharge b c) := by
  constructor
  · intro ⟨c, hwc⟩
    unfold derivedWeight at hwc
    by_cases h : isBalancedCharge b c
    · simp only [h, if_true] at hwc
      exact ⟨hwc, c, h⟩
    · simp only [h, if_false] at hwc
      exact absurd rfl hwc
  · intro ⟨hscale, c, hbc⟩
    refine ⟨c, ?_⟩
    unfold derivedWeight
    simp only [hbc, if_true]
    exact hscale

theorem symmetric_exists_iff (b : BalanceCoeffs) :
    (∃ w, isSymmetric b w) ↔ (∃ c, isBalancedCharge b c) := by
  constructor
  · intro ⟨w, hsym⟩
    obtain ⟨hbal, c, hwc⟩ := hsym
    have hbc := hbal c
    have hsub : b.α c - b.ω c = 0 := by
      rcases Int.mul_eq_zero.mp hbc with h1 | h2
      · exact absurd h1 hwc
      · exact h2
    refine ⟨c, ?_⟩
    show b.α c = b.ω c
    omega
  · intro ⟨c, hbc⟩
    refine ⟨derivedWeight b 1, derivedWeight_balanced b 1, ?_⟩
    apply (derivedWeight_nondeg_iff b 1).mpr
    refine ⟨?_, c, hbc⟩
    decide

end Weights

end GOG

#print axioms GOG.GapShape.deposit_dominates
#print axioms GOG.GapShape.deposit_raises_at_or_above
#print axioms GOG.GapShape.deposit_compose_monotone
#print axioms GOG.Cheeger.cert_yields_deposit
#print axioms GOG.Cheeger.cert_carries_up
#print axioms GOG.MetaAxiom.substrateCostAfter_monotone
#print axioms GOG.MetaAxiom.substrateCostAfter_le_append_left
#print axioms GOG.MetaAxiom.alphaMaxCost_le_substrate
#print axioms GOG.MetaAxiom.omegaMaxCost_le_substrate
#print axioms GOG.MetaAxiom.substrateCost_eq_max
#print axioms GOG.Weights.zero_balanced
#print axioms GOG.Weights.derivedWeight_balanced
#print axioms GOG.Weights.derivedWeight_nondeg_iff
#print axioms GOG.Weights.symmetric_exists_iff
